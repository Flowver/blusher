Mac OS X Cursors for Windows 2000/XP
------------------------------------
Here is a set of alphablended cursors for Windows 2000 and XP.
The shadow is already included as transparency bits.  Some of you might have alphablending problems, if you do, please look at the tip below it might work for you.
It does not for me :(

I will be releasing another pack without the shadow, it might fix the problem cuz you can click on "Enable pointer shadow" from the Control Panel/Mouse screen.

I do not know who is the original author of the icons ... probably Apple ;)
If you know, I will gladly post it in here.
I know that Binary posted the cursor files here http://www.neowin.net/forum/index.php?showtopic=53960
But it does not say how actually rip the ressources and created the .cur/.ani files.

Install
-------
- Extract the archive to a temporary folder.
- Right click the "Install xxxxxx.inf" file and click on "Install"
- Choose the cursorset in the control panel mouse applet
  They appear as "Mac OS X Aqua", "Mac OS X Aqua Swirl", 
  "Mac OS X Graphite", "Mac OS X Graphite Swirl", 
  "Mac OS X Radioactive", "Mac OS X Rainbow Swirl"

Troubleshooting
---------------
When the shadow on the cursors look like crap (which can happen on
some systems) you should turn 2D hardware acceleration a nod down.
You can do that this way:
- Display Properties -> Settings -> Advanced -> Troubleshoot
- Set "Hardware Acceleration" one nod down

Packages
--------
- Aqua (regular "4-pieces" blob)
- Aqua Swirl
- Graphite
- Graphite Swirl
- Radioactive (radioactive sign blob)
- Rainbow Swirl

Changelog
---------
v.1.0 - 2006/01/09  Original Release
v.1.1 - 2006/01/10  Reorganized the files so that we don't have 6 copies of the same cursors :P

Enjoy it!!

Greetings,

RaZcaL inSIDe
http://razcalinside.deviantart.com
